package shopping;

import java.util.List;

public interface ProductsDAO {

	public List<Category_Model> getAllCategories();

	public List<Products_Model> getAllProducts();

	public List<Products_Model> getProducts(String category);

}
