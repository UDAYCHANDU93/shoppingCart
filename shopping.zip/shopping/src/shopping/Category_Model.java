package shopping;

public class Category_Model {

	String category;

	public Category_Model(String category) {
		this.category = category;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}
