package shopping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductsDAL implements ProductsDAO {

	public String url = "jdbc:postgresql://192.168.110.48:5432/plf_training";
	public String uname = "plf_training_admin";
	public String password = "pff123";

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public ProductsDAL() throws ClassNotFoundException {
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url, uname, password);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public List<Category_Model> getAllCategories() {

		List<Category_Model> categories = new ArrayList<>();

		try {

			ps = con.prepareStatement("select prct_title from productcategories_i189");
			rs = ps.executeQuery();
			while (rs.next()) {

				categories.add(new Category_Model(rs.getString(1)));

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		return categories;

	}

	public List<Products_Model> getAllProducts() {

		List<Products_Model> products = new ArrayList<>();

		try {

			ps = con.prepareStatement(
					"select p.*,s.prod_price,s.prod_stock,s.prod_mrp from productsItems_i189 p join productstock_I189 s on p.prod_id=s.prod_id");
			rs = ps.executeQuery();
			while (rs.next()) {
				products.add(new Products_Model(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4),
						rs.getString(5), rs.getString(6), rs.getInt(7), rs.getInt(8), rs.getInt(9)));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return products;

	}

	public List<Products_Model> getProducts(String category) {

		List<Products_Model> products = new ArrayList<>();
		try {

			ps = con.prepareStatement(
					"select p.*,s.prod_price,s.prod_stock,s.prod_mrp from productsItems_i189 p join productcategories_I189 c on p.prod_prct_id=c.prct_id join productstock_i189 s on s.prod_id=p.prod_id where prct_title=?");
			ps.setString(1, category);
			rs = ps.executeQuery();
			while (rs.next()) {
				products.add(new Products_Model(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4),
						rs.getString(5), rs.getString(6), rs.getInt(7), rs.getInt(8), rs.getInt(9)));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return products;
	}

}
