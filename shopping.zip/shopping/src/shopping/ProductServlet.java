package shopping;

import java.io.IOException;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		ProductsDAO products;
		try {
			products = new ProductsDAL();
			List<Products_Model> product = products.getAllProducts();

			Gson gson = new Gson();
			String json = gson.toJson(product);
			res.setContentType("application/json");
			System.out.println(json);
			res.getWriter().print(json);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {

		ProductsDAO ob;
		String cat = req.getParameter("category");
		try {
			ob = new ProductsDAL();
			List<Products_Model> products = ob.getProducts(cat);

			Gson gson = new Gson();
			String json = gson.toJson(products);
			res.setContentType("application/json");
			res.getWriter().print(json);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Set response content type to JSO
	}

}
