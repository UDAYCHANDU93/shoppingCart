package shopping;

import java.io.IOException;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/store")
public class StoreServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		ProductsDAO ob;
		try {
			ob = new ProductsDAL();
			List<Category_Model> categories = ob.getAllCategories();
			for (Category_Model i : categories) {
				System.out.println(i.getCategory());

			}
			Gson gson = new Gson();
			String json = gson.toJson(categories);
			res.setContentType("application/json");
			res.getWriter().print(json);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Set response content type to JSO
	}

}
