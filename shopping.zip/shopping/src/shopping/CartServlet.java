package shopping;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/addToCart")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Get parameters from request
		String title = request.getParameter("title");
		String brand = request.getParameter("brand");
		double price = Double.parseDouble(request.getParameter("price"));

		// Create a product object
		CartProduct_Model product = new CartProduct_Model(title, brand, price);

		// Get the session object
		HttpSession session = request.getSession();

		// Get the cart list from session, or create a new one if it doesn't exist
		List<CartProduct_Model> cart = (List<CartProduct_Model>) session.getAttribute("cart");
		if (cart == null) {
			cart = new ArrayList<>();
		}

		// Add the product to the cart
		cart.add(product);

		// Update the cart attribute in session
		session.setAttribute("cart", cart);

		// Set response content type
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");

		// Send a success message back to the client
		response.getWriter().write("Product added to cart successfully!");
	}
}